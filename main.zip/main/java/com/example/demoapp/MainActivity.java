package com.example.demoapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText tx1 = findViewById(R.id.editTextNumber);
        EditText tx2 = findViewById(R.id.editTextNumber2);
        Button resetButton = findViewById(R.id.button2);
        TextView txtvie = findViewById(R.id.textView4);

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tx1.setText("");
                tx2.setText("");
                txtvie.setText("");
            }
        });

        Button btn = findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text1 = tx1.getText().toString();
                String text2 = tx2.getText().toString();

                if (text1.isEmpty() || text2.isEmpty()) {
                    txtvie.setText("Fields can't be empty");
                    tx1.setHint("Enter first number");
                    tx2.setHint("Enter second number");
                    return;
                }

                int number1;
                int number2;

                try {
                    number1 = Integer.parseInt(text1);
                    number2 = Integer.parseInt(text2);
                } catch (NumberFormatException e) {
                    txtvie.setText("Invalid input. Please enter valid numbers.");
                    return;
                }

                int res = number1 + number2;

                Toast.makeText(getApplicationContext(), "The result is: " + res, Toast.LENGTH_SHORT).show();
                txtvie.setText(String.valueOf(res));
            }
        });
    }
}
